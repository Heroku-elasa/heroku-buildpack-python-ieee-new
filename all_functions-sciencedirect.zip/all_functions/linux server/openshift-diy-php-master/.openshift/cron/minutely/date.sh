#!/bin/bash
# The logic to start up your application should be put in this
# script. The application will work only if it binds to
# $OPENSHIFT_INTERNAL_IP:8080

# Start apache if present
curl http://elasa.ir
curl http://php-stairlift.rhcloud.com/gl/browse.php?u=Oi8vZWxhc2EuaXI%3D&b=13&f=norefer
curl http://bigfishs.tk/diy-diy4ss.rhcloud.com