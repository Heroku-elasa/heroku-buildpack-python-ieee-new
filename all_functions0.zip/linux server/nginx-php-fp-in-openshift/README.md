nginx-php-fp-in-openshift
=========================

nginx php-fp in openshift
