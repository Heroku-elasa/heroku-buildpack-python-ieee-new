grep -r 'Test String' /var/spool/asterisk/voicemail/Folder/*.php
find  -type f -exec grep -H 'free-papers.tk' {} +