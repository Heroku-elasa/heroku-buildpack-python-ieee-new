# Version 0.2.1
  - Add cache to file/folder lookup to speed up access to known folders, cache is not stored between runs.

# Version 0.2.0
  - Updated to external special remote protocol

# Version 0.1.2
  - Bugfix

# Version 0.1.1
  - Rate limiting

# Version 0.1.0
  - Bugfixes
