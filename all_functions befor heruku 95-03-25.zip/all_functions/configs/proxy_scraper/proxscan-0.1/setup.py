#! /usr/bin/env python

from distutils.core import setup
setup(name="proxscan",
      version="0.1",
      py_modules = ["proxscan"],
      author="Iury O. G. Figueiredo",
      author_email="robatsch@hotmail.com",
      url="http://proxscan.sourceforge.net/")
