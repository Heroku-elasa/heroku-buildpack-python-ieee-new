<?php echo phpinfo();
