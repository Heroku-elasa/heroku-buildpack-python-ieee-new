<?php

header("content-type: text/xml");
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
?>
<Response>
  <Dial>
    <Sip username="ss_sab" password="ss123456">sip:ss_sab:ss123456@sip.linphone.org</Sip>
  </Dial>
</Response>

