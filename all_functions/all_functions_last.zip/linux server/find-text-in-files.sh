	grep -r 'js/tinymce/jscripts/tiny_mce' $HOME/app-root/runtime/repo/p2/*
grep -r 'sale' $HOME/app-root/runtime/repo/php/p6*

find  -type f -exec grep -H 'display_errors' {} +