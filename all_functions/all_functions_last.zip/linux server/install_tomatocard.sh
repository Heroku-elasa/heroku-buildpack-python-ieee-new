cd /tmp
rm -rf *
#wget http://dl.nuller.ir/tomatocart-v1.1.5-persian%5Bwww.nuller.ir%5D.zip

wget http://dl.nuller.ir/tomatocart-v1.1.8.1-persian%5BNuLLeR.iR%5D.zip
unzip t*
 #cd t*
 mkdir $HOME/app-root/runtime/repo/t2
cp -fauv   * $HOME/app-root/runtime/repo/t2

mv * $OPENSHIFT_HOMEDIR/app-root/repo
cd /tmp
mkdir tt
cd tt
wget https://de.zarinpal.com/files/labfiles/WebGate-TomatoCart.zip
#wget http://forum.tomatoshop.ir/Thread-%D9%85%D8%A7%DA%98%D9%88%D9%84-%D9%BE%D8%B1%D8%AF%D8%A7%D8%AE%D8%AA-%D8%B2%D8%B1%DB%8C%D9%86-%D9%BE%D8%A7%D9%84
unzip *
cd S*
unzip  zarinpal.zip
mkdir $HOME/app-root/runtime/repo
cp -fauv   zarinpal/* $HOME/app-root/runtime/repo
##SMS
cd /tmp

wget http://www.mediana.ir/file/ippanel-Tomato.zip
unzip i*
cd i*
cp -fauv   * $HOME/app-root/runtime/repo

