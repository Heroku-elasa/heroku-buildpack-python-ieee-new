<!DOCTYPE html>
<html lang="en">
    <head>
        <title>PHP <?php echo PHP_VERSION ?> @ openshift</title>
    </head>
    <body>
        <h1>Hi there!</h1>
        <p>Yes, it's true! On this openshift gear PHP <?php echo PHP_VERSION ?> is running.</p>
        <p>Have phun!</p>
    </body>
</html>
