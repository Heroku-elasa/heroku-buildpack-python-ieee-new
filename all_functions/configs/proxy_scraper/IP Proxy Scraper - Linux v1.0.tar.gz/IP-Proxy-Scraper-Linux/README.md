IP Proxy Scraper-Linux
======================

A lightweight and easy to use tool to extract multiple proxy server from a list of websites!

    Requirements for this tool:
    Colorama:   https://pypi.python.org/pypi/colorama
    Python 2.7.5:   http://www.python.org/download/releases/2.7.5/


IP Proxy Scraper is available for Windows and Linux, this is the Linux version.
The Windows version can be found on my website: http://www.daapii.users.sourceforge.net/Projects/IP%20Proxy%20Scraper.html

Thanks for using IP Proxy Scraper!




Contact
=========

Feedback, problems, questions or something else?
Feel free to contact me, devdaapii@gmail.com
or visit me on my website http://www.daapii.users.sourceforge.net


Bugs/Issues
=========

Please report any bugs or issues you might encounter while using IP Proxy Scraper,
any help is greatly appreciated!
